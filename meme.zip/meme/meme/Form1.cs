﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace meme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string enterUser = textBox1.Text;
            string enterPass = textBox2.Text;

            string user = "admin";
            string pass = "12345";

            if (enterUser == user && enterPass == pass)
            {
                // login success
                label3.Visible = false;
                Form1 varForm1 = new Form1();
                //Form2 varForm2 = new Form2();
                //varForm1.Visible = false;
                //varForm2.Visible = true;

                for (int i = 0; i < 300; i++)
                {
                    Form2 varForm2 = new Form2();
                    varForm2.BackColor = Color.Black;
                    varForm2.Visible = true;
                    Form2 varForm3 = new Form2();
                    varForm3.BackColor = Color.White;
                    varForm3.Visible = true;
                }

            }

            else
            {
                label3.Visible = true;
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "admin";
            textBox2.Text = "12345";
        }
    }
}
